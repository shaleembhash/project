-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 15, 2017 at 07:22 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `farmer`
--

-- --------------------------------------------------------

--

-- --------------------------------------------------------

-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `type`) VALUES
('admin', '1234', 'admin'),
('akshu@gmail.com', '13187', 'farmer');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `age` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`fname`, `lname`, `age`,  `phone`, `email`) VALUES
('akshata', 'm', '0000-00-00',  '7760143639', 'akshu@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `Equipments_details`
--

CREATE TABLE IF NOT EXISTS `Equipments_details` (
  `equ_id` int(11) NOT NULL,
  `equ_name` varchar(50) NOT NULL,
  `former_name` varchar(50) NOT NULL,
  `village` varchar(50) NOT NULL,
  `taluk` varchar(50) NOT NULL,
  `district`varchar(50) NOT NULL,
  `adress` varchar(50) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `rentperday`varchar(50) NOT NULL
) ;

--
-- Dumping data for table `Equipments_details`
--

INSERT INTO `Equipments_details` (`equ_id`, `equ_name`, `former_name`, `village`,`taluk`,`district`,`adress`,`mobile_no`,`rentperday`) VALUES
(29, 'vgvg', 'cc', 'BVNB','vdciw','gdewudf','spbc2','sbcuo7','cbk;vb9');


-- Table structure for table `fertilizer_detail`
--

CREATE TABLE IF NOT EXISTS `fertilizer_detail` (
  `fer_id` int(11) NOT NULL,
  `fer_name` varchar(40) NOT NULL,
  `usage` varchar(400) NOT NULL,
  `details` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fertilizer_detail`
--

INSERT INTO `fertilizer_detail` (`fer_id`, `fer_name`, `usage`, `details`) VALUES
(30,  'darmu', 'Produces leaf spots, blossom blight, wither tip',  'Spray P. fluorescens ');

-- Table structure for table `seeds_detail`
--

CREATE TABLE IF NOT EXISTS `seeds_detail` (
  `seed_id` int(11) NOT NULL,
  `seed_name` varchar(40) NOT NULL,
  `usage` varchar(400) NOT NULL,
  `details` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seeds_detail`
--

INSERT INTO `seeds_detail` (`seed_id`, `seed_name`, `usage`, `details`) VALUES
(30,  'darmu', 'Produces leaf spots, blossom blight, wither tip',  'Spray P. fluorescens ');

-- Table structure for table `pesticides_details`
--

CREATE TABLE IF NOT EXISTS `pesticides_details` (
  `pest_id` int(11) NOT NULL,
  `pest_name` varchar(40) NOT NULL,
  `whentouse` varchar(400) NOT NULL,
  `howtouse` varchar(40) NOT NULL,
  `usedfor` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesticides_details`
--

INSERT INTO `pesticides_details` (`pest_id`, `pest_name`, `whentouse`, `howtouse`,`usedfor`) VALUES
(27,  'kasa', 'Produces leaf spots, blossom blight, wither tip',  'Spray P. fluorescens ','kasacleaning');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- Add seeds detais
--
CREATE TABLE seeds (
    seeds_id INT  AUTO_INCREMENT PRIMARY KEY,
    seed_name VARCHAR(50) NOT NULL,
    when_to_use VARCHAR(255) NOT NULL,
    how_to_use TEXT NOT NULL,
    seed_image LONGBLOB NOT NULL
);
--
-- Add fertilizer
--
CREATE TABLE fertilizers (
    fer_id INT  AUTO_INCREMENT PRIMARY KEY,
    fer_name VARCHAR(50) NOT NULL,
    when_to_use VARCHAR(255) NOT NULL,
    how_to_use TEXT NOT NULL,
    fertilizer_image LONGBLOB NOT NULL
);
--
--


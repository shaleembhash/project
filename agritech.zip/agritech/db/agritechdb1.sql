
CREATE TABLE pesticides (
    pest_id INT AUTO_INCREMENT PRIMARY KEY,
    pest_name VARCHAR(50) NOT NULL,
    details VARCHAR(200) NOT NULL,
    when_to_use VARCHAR(255) NOT NULL,
    how_to_use TEXT NOT NULL,
    pesticide_image LONGBLOB NOT NULL
);

CREATE TABLE farmers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    F_name VARCHAR(30) NOT NULL,
    Age INT(2) NOT NULL,
    Village VARCHAR(255) NOT NULL,
    Address VARCHAR(255) NOT NULL,
    Phone_no VARCHAR(10) NOT NULL,
    Password VARCHAR(10) NOT NULL
);

CREATE TABLE IF NOT EXISTS `equipments` (
  `equipmentid` varchar(10) NOT NULL,
  `former_name` varchar(50) NOT NULL,
  `equipment_name` varchar(50) NOT NULL,
  `village` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile_number` varchar(10) NOT NULL,
  `equipment_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

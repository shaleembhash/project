CREATE TABLE equipment (
    equipment_id INT AUTO_INCREMENT PRIMARY KEY,
    farmer_name VARCHAR(255),
    equipment_name VARCHAR(255),
    village VARCHAR(255),
    address VARCHAR(255),
    mobile_number VARCHAR(15),
    image BLOB
);

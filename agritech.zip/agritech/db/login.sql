CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(56) NOT NULL,
  `password` varchar(56) NOT NULL,
  `utype` varchar(56) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `login` (`username`, `password`, `utype`) VALUES
('null', 'null', 'citizens');
